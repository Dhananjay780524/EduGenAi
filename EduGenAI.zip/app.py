import os
import streamlit as st
import openai
import sqlite3
import json
from datetime import datetime

# ---------- Configuration ----------
OPENAI_KEY = os.environ.get("OPENAI_API_KEY")
if not OPENAI_KEY:
    st.warning("OPENAI_API_KEY environment variable not set. Set it before running: export OPENAI_API_KEY='your_key'")
openai.api_key = OPENAI_KEY

DB_PATH = "edugenai_progress.db"

# ---------- DB helpers ----------
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS progress (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user TEXT,
        mode TEXT,
        topic TEXT,
        result TEXT,
        timestamp TEXT
    )""")
    conn.commit()
    conn.close()

def save_progress(user, mode, topic, result):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("INSERT INTO progress (user, mode, topic, result, timestamp) VALUES (?,?,?,?,?)",
                (user, mode, topic, json.dumps(result), datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()

def get_progress(user=None, limit=50):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    if user:
        cur.execute("SELECT user, mode, topic, result, timestamp FROM progress WHERE user=? ORDER BY id DESC LIMIT ?", (user, limit))
    else:
        cur.execute("SELECT user, mode, topic, result, timestamp FROM progress ORDER BY id DESC LIMIT ?", (limit,))
    rows = cur.fetchall()
    conn.close()
    return rows

# ---------- OpenAI helpers ----------
def chat_with_gpt(system_prompt, user_prompt, temperature=0.2):
    if not openai.api_key:
        return "OpenAI API key not configured."
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ]
    try:
        resp = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages,
            temperature=temperature,
            max_tokens=800
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        return f"OpenAI request failed: {e}"

def generate_quiz_questions(topic, num=5, difficulty="medium"):
    system = "You are an assistant that generates educational quizzes. Output must be valid JSON."
    user = f"""Generate {num} quiz questions on the topic: "{topic}".
Format JSON exactly as:
{{"topic": "...", "questions": [{{"q":"...", "type":"mcq"|"short", "options":["A","B","C","D"], "answer_index":0, "explain":"..." } , ...]}}
Use difficulty: {difficulty}. Keep questions clear and concise."""
    out = chat_with_gpt(system, user, temperature=0.3)
    # Try to recover JSON from response
    try:
        # sometimes model returns extra text; find first brace
        first = out.find("{")
        json_str = out[first:]
        data = json.loads(json_str)
        return data
    except Exception as e:
        return {"error": "Failed to parse JSON from model response.", "raw": out}

# ---------- Streamlit UI ----------
st.set_page_config(page_title="EduGenAI - Universal Learning Assistant", layout="wide")
init_db()

st.title("EduGenAI — Universal AI Learning Assistant")
st.markdown("Prototype for Buildathon / Workshop. Supports: Ask Doubt, Quiz Generator, Language Practice, Career Guidance, Progress tracking.")

with st.sidebar:
    st.header("User")
    user_name = st.text_input("Enter your name", value="guest")
    mode = st.selectbox("Select mode", ["Ask Doubt", "Generate Quiz", "Language Practice", "Career Guidance", "Upload Homework (image)", "View Progress"])
    st.markdown("---")
    if st.button("Reset DB"):
        open('edugenai_progress.db','w').close()
        init_db()
        st.success("Database reset.")

# Modes
if mode == "Ask Doubt":
    st.subheader("Ask any academic doubt (school, college, competitive exams)")
    topic = st.text_input("Subject / Topic (e.g., Algebra: Quadratic equations)")
    question = st.text_area("Type your question (show steps you want the student to see)")
    difficulty = st.selectbox("Level", ["easy","medium","hard"])
    if st.button("Get Explanation"):
        with st.spinner("Contacting AI..."):
            sys = "You are a helpful tutor. Give clear step-by-step explanations. Do not simply give the final answer; instead provide hints and method, and then show the final answer at the end labeled 'Final Answer'. Keep language simple."
            prompt = f"Topic: {topic}\nDifficulty: {difficulty}\nQuestion: {question}\nProvide step-by-step explanation, and then Final Answer."
            ans = chat_with_gpt(sys, prompt, temperature=0.2)
            st.markdown("**AI Explanation:**")
            st.write(ans)
            save_progress(user_name, mode, topic or "general", {"question": question, "answer_excerpt": ans[:300]})
elif mode == "Generate Quiz":
    st.subheader("Auto Quiz Generator")
    topic = st.text_input("Topic or Chapter (e.g., Photosynthesis, Integration, World War II)")
    num = st.slider("Number of questions", 3, 10, 5)
    difficulty = st.selectbox("Difficulty", ["easy","medium","hard"], index=1)
    if st.button("Generate Quiz"):
        with st.spinner("Generating quiz..."):
            data = generate_quiz_questions(topic or "general knowledge", num=num, difficulty=difficulty)
            if "error" in data:
                st.error("Failed to generate structured quiz. Raw output:")
                st.write(data.get("raw"))
            else:
                st.success("Quiz generated. You can take it below.")
                # Display quiz and allow taking it
                answers = []
                for i, q in enumerate(data.get("questions", [])):
                    st.write(f"**Q{i+1}. {q.get('q')}**")
                    if q.get("type") == "mcq":
                        opt = q.get("options", [])
                        choice = st.radio(f"Select answer for Q{i+1}", options=opt, key=f"q{i}")
                        answers.append({"index": opt.index(choice), "correct": q.get("answer_index")})
                    else:
                        ans = st.text_input(f"Your short answer for Q{i+1}", key=f"s{i}")
                        answers.append({"answer_text": ans, "correct": None})
                if st.button("Submit Quiz"):
                    score = 0
                    total = 0
                    for a, q in zip(answers, data.get("questions", [])):
                        if q.get("type") == "mcq":
                            total += 1
                            if a["index"] == q.get("answer_index"):
                                score += 1
                        else:
                            # for short answers, do a rough auto-eval via model
                            total += 1
                            sys = "You are a strict grader. Given question and a student's short answer decide if it's correct. Return 'CORRECT' or 'INCORRECT' with one-line reason."
                            prompt = f"Question: {q.get('q')}\nExpected (model): {q.get('explain')}\nStudent answer: {a['answer_text']}\nAnswer briefly with CORRECT or INCORRECT."
                            eval_r = chat_with_gpt(sys, prompt, temperature=0.0)
                            if eval_r.upper().startswith("CORRECT"):
                                score += 1
                    st.success(f"You scored {score} / {total}")
                    save_progress(user_name, mode, topic or "general", {"score": f"{score}/{total}"})
elif mode == "Language Practice":
    st.subheader("Language Practice (Marathi, Hindi, English)")
    target_lang = st.selectbox("Practice language", ["English","Hindi","Marathi"])
    scenario = st.text_input("Scenario (e.g., 'Introduce yourself', 'Ask for directions')")
    user_text = st.text_area("Speak / Type (AI will respond and correct grammar)")
    if st.button("Practice"):
        with st.spinner("Talking to AI..."):
            sys = f"You are a helpful language tutor for {target_lang}. Correct grammar, suggest better phrases, and give 3 improvement tips. Also provide a short role-play reply if appropriate."
            prompt = f"Scenario: {scenario}\nUser input: {user_text}\nRespond with corrected version, explanation, and tips."
            out = chat_with_gpt(sys, prompt, temperature=0.4)
            st.write(out)
            save_progress(user_name, mode, scenario or "conversation", {"input": user_text, "reply_preview": out[:250]})
elif mode == "Career Guidance":
    st.subheader("Career Guidance")
    interests = st.text_input("Enter your interests / favorite subjects (comma separated)")
    strengths = st.text_input("Strengths (e.g., problem solving, writing, drawing, coding)")
    education_level = st.selectbox("Education level", ["School (10th or below)", "Higher Secondary (11-12)", "Undergraduate", "Graduate / Professional"])
    if st.button("Get Guidance"):
        with st.spinner("Analyzing..."):
            sys = "You are a career counselor. Provide suitable careers, required paths, example colleges/courses, and short 1-year action plan for skill-building. Tailor answers to the education level provided."
            prompt = f"Interests: {interests}\nStrengths: {strengths}\nEducation level: {education_level}\nGive 5 suitable career options with short actions."
            out = chat_with_gpt(sys, prompt, temperature=0.3)
            st.write(out)
            save_progress(user_name, mode, "career", {"interests": interests, "summary": out[:300]})
elif mode == "Upload Homework (image)":
    st.subheader("Upload a photo of handwritten/homework question")
    uploaded = st.file_uploader("Upload image (photo of question)", type=["png","jpg","jpeg"])
    hint = st.checkbox("If OCR not working, paste the question text below")
    if uploaded:
        st.image(uploaded, caption="Uploaded image", use_column_width=True)
        st.info("This prototype does not run OCR reliably in this environment. If the image is clear, paste the text in the box below before asking.")
    qtext = st.text_area("Paste question text (recommended for reliability)")
    if st.button("Explain Homework"):
        if not qtext.strip():
            st.error("Please paste the question text (better reliability).")
        else:
            with st.spinner("AI is explaining..."):
                sys = "You are a tutor. Explain the pasted homework question step-by-step and give hints so the student learns to solve themselves. At the end, show final answer labeled 'Final Answer'."
                out = chat_with_gpt(sys, qtext, temperature=0.2)
                st.write(out)
                save_progress(user_name, mode, "homework", {"question": qtext[:300], "answer_excerpt": out[:300]})
elif mode == "View Progress":
    st.subheader("Student Progress / Activity")
    st.markdown("Recent activity (latest 50)")
    rows = get_progress(user_name)
    for r in rows:
        st.markdown(f"- **Mode:** {r[1]} | **Topic:** {r[2]} | **When:** {r[4]}")
        st.write(r[3])

st.markdown("---")
st.markdown("**Notes:** This is a demo prototype. Replace the OpenAI model name if you have access to different models. App stores simple progress locally in a sqlite DB file `edugenai_progress.db`.")
