# EduGenAI — Universal AI Learning Assistant (Prototype)

This is a Streamlit-based prototype for an education-focused GenAI assistant built for the OpenAI NxtWave Buildathon.

## Features
- Ask Doubt: Step-by-step explanations (school/college/competitive).
- Generate Quiz: Auto-generate MCQs/short questions from a topic and evaluate.
- Language Practice: Practice English/Hindi/Marathi with corrections and tips.
- Career Guidance: AI suggestions and 1-year action plan.
- Upload Homework: Accepts image/text of questions and explains them.
- Progress Tracking: Stores user interactions in a local SQLite DB.

## How to run
1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set your OpenAI API key (Linux/macOS):
```bash
export OPENAI_API_KEY="your_api_key"
```
On Windows (PowerShell):
```powershell
$env:OPENAI_API_KEY="your_api_key"
```

3. Run the app:
```bash
streamlit run app.py
```

## Notes & customization
- The app uses `gpt-3.5-turbo` by default. Change the model name in `app.py` if you have access to other models.
- The "Upload Homework" mode does **not** include OCR in this prototype. For reliable text extraction from images, integrate Tesseract (`pytesseract`) or a vision-capable OpenAI model.
- This prototype stores a simple local SQLite DB file `edugenai_progress.db` in the app folder.

Good luck with your Buildathon! If you want, I can:
- Convert this to a React + FastAPI project.
- Add OCR (pytesseract) support and image-to-text flow.
- Add authentication (Firebase) and deploy instructions.
